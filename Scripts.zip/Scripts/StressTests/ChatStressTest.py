import mysql.connector

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import time
import threading
import datetime

import string
import random

import requests
import json
from http.client import HTTPSConnection
from requests.auth import HTTPBasicAuth

global driver


global driver
driver = webdriver.Chrome()
driver.get("https://app.gabriel.network/emergency")
mydb = mysql.connector.connect(
host="35.196.136.146",
user="root",
passwd="Gabriel@2018",
database="gabriel"
)

def Login():

    TypeEmail = driver.find_element_by_name("email").send_keys('sho@sho.sho')
    TypePassword = driver.find_element_by_name('password').send_keys('gabriel')
    Submit = driver.find_element_by_css_selector("button").click() #submit
    Hold4sec = time.sleep(1)
    TypeEmail
    TypePassword
    Submit
    Hold4sec
    return

def CheckingIfThereIsEventOrNot():

    mycursor = mydb.cursor()
    mycursor.execute("select status from PrxEvent where propertyId = 1 order by eventId desc limit 1;")
    EventId = mycursor.fetchall()

    status = " ".join(str(EventId))
    print("The status is" + status)
    CheckingIfThereIsEventOrNot.status = status
    return

def StartEmergenctInJFMD():

    PlusIcon = driver.find_element_by_xpath('//*[@id="root"]/div/span/div/div[2]/ul/div/li[1]').click() # plus icon
    ClickOnLockDown = driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/div/div/div[2]/button[1]").click() #lockdown
    ClickOnArrow = driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/div/div/div[2]/div[1]/div/span[2]").click() #Arrow
    TypeJFMD = driver.find_element_by_xpath('//*[@id="react-select-2--value"]/div[2]/input').send_keys('Gabriel - demo' + "\n")#jfmd
    ClickOnStart = driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/div/div/div[2]/div[3]").click() #START

    PlusIcon
    ClickOnLockDown
    ClickOnArrow
    TypeJFMD
    ClickOnStart

    return
def CloseTwoEvents():
    driver.find_element_by_class_name('emergency-type-dropdown').click()
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/nav/div/ul[3]/li/ul/li[3]/a/div').click()#end energency
    time.sleep(4)
    driver.find_element_by_xpath('//*[@id="root"]/div/span/div/div[2]/ul/div/li[1]/a').click()#belIcon
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="root"]/div/span/div[1]/div/div/div[1]').click() #JCC
    time.sleep(10)
    driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/nav/div/ul[3]').click()
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/nav/div/ul[3]/li/ul/li[3]').click()#end energency
    time.sleep(5)

    return

def id_generator(size=16, chars=string.ascii_uppercase + string.digits):

    id_generator.a = ( ''.join(random.choice(chars) for _ in range(size)))
    id_generator.b = ( ''.join(random.choice(chars) for _ in range(size)))
    id_generator.c = ( ''.join(random.choice(chars) for _ in range(size)))
    id_generator.d = ( ''.join(random.choice(chars) for _ in range(size)))

    return

def AllRelevantUsers():
    mycursor = mydb.cursor()
    mycursor.execute("select PrxUser.firstName from RelevantpropertyId RIGHT JOIN PrxUser on RelevantpropertyId.userId = PrxUser.userId ORDER BY PrxUser.userId;")
    RelevantUsers = mycursor.fetchall()
    print(RelevantUsers)
    return

def ChatStressTest():
    time.sleep(5)
    for i in range (30):
        id_generator()
        driver.find_element_by_class_name('form-control').send_keys(id_generator.a + " " + id_generator.b + " " + id_generator.c + " " + id_generator.d + "\n")#ChatButton
        time.sleep(5)

    return

def MainFunction():
    Login()
    CheckingIfThereIsEventOrNot()
    if CheckingIfThereIsEventOrNot.status == "[ ( 1 , ) ]" :
       StartEmergenctInJFMD()
    else:
       CloseTwoEvents()
       StartEmergenctInJFMD()
    ChatStressTest()

    return

MainFunction()
