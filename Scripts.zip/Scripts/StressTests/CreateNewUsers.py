import requests
import json
from http.client import HTTPSConnection
from requests.auth import HTTPBasicAuth

import string
import random

NumberOfUsers = int(raw_input("How many Users do you wantg to add? "))
customerId = int(raw_input("Choose customer id : "))
propertyId = int(raw_input("Choose property id : "))
Generalnumbers int(raw_input("How many s do you wantg to add? ""))


role = 3
size =4
sizeDigit = 12

chars = string.ascii_uppercase
digit = string.digits

print("I started")
devLogin = "https://dev.gabriel.network/api/v1/login"
prodLogin = "https://app.gabriel.network/api/v1/login"
devRegister = "https://dev.gabriel.network/api/v2/register"
prodRegister = "https://app.gabriel.network/api/v2/register"



def Login():

    login_data =  {"email":"shoshan@gabriel.network", "password": "gabriel"}
    s= requests.Session()
    r = s.post(devLogin, json=login_data )

    json_data_post = json.loads(r.text)
    Login.cookies = r.cookies


    return (Login.cookies)


def AddingUsers():


    print(type(propertyId))
    email = (''.join(random.choice(chars) for _ in range(size))) + "@test.test"
    firstName = (''.join(random.choice(chars) for _ in range(size)))
    lastName = (''.join(random.choice(chars) for _ in range(size)))
    phone = "+" + (''.join(random.choice(digit) for _ in range(sizeDigit)))

    AddingUserData = {"customerId": customerId, "propertyIds" : [propertyId] ,"email": email, "firstName": firstName, "lastName": lastName, "phone": phone, "role": role}
    print(AddingUserData)
    resp = requests.post(devRegister, json = AddingUserData, cookies = Login.cookies )
    json_data = json.loads(resp.text)
    # print(json_data.requestGuid)
    # print(json_data.requestGuid)
    print("")
    print("The Response of Adding Users is" )
    print(resp)

    return



Login()
for i in range (NumberOfUsers):
    AddingUsers()
