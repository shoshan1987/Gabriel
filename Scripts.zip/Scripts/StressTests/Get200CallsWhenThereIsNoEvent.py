import requests
import json
from http.client import HTTPSConnection
from requests.auth import HTTPBasicAuth
import datetime
import time
import threading


def Get200CallsWhenThereIsNoEvent ():
    login_data =  {"email":"security@customer1.com", "password": "gabriel"}
    s= requests.Session()
    r = s.post('https://dev.gabriel.network/api/v1/login', json=login_data )

    json_data_post = json.loads(r.text)
    cookies = r.cookies
    print(json_data_post["json"]["user"]["email"])
    MakeCallOfGetPropertyAll(cookies)

    return


def repeat_fun(times):
    for i in range(0,times):
        Get200CallsWhenThereIsNoEvent()

    return


def MakeCallOfGetPropertyAll(cookies):

    resp = requests.get('https://dev.gabriel.network/api/v1/property/all', cookies=cookies)
    json_data = json.loads(resp.text)
    print(resp)
    t=threading.Timer(5.0, MakeCallOfGetPropertyAll, [cookies])
    t.start()

    return

times=input("How many times do you want to run the script in a loop?: ")
repeat_fun(times)

#    urllib.request.urlopen("http://domain.tld?parameter=value&parameter2=value").read()
