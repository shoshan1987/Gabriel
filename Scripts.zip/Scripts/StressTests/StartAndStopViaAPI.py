import requests
import json
from http.client import HTTPSConnection
from requests.auth import HTTPBasicAuth
import mysql.connector
from datetime import datetime
import time
from calendar import timegm

print("I started")

mydb = mysql.connector.connect(
host="35.196.136.146",
user="root",
passwd="Gabriel@2018",
database="gabriel"
)
mycursor = mydb.cursor()


def Login():

    login_data =  {"email":"shoshan@gabriel.network", "password": "gabriel"}
    s= requests.Session()
    r = s.post('https://app.gabriel.network/api/v1/login', json=login_data )

    json_data_post = json.loads(r.text)
    Login.cookies = r.cookies


    return (Login.cookies)



def APIStartEventCall():
    print("")
    print("I entered to APIStartEventCall function")
    print("")
    start_data = {"propertyId": 14,  "eventLevel": 0, "eventType": 0,"emergencyType": 0, "initiatorClient": 2  }
    print(start_data)
    resp = requests.post("https://app.gabriel.network/api/v1/event/start", json = start_data, cookies = Login.cookies )
    json_data = json.loads(resp.text)
    print(json_data.requestGuid)
    print("")
    print("The Response of start is" )
    print(resp)
    return

def APIStopEventCall():

    print("")
    print("I entered to APIStopEventCall function")
    print("")

    mycursor.execute("select eventId from PrxEvent where status =0 order by eventId desc limit 1")

    for (item) in mycursor:
        EventId = item[0]

    stop_data ={"eventId": EventId }
    print(stop_data)
    resp = requests.post("https://app.gabriel.network/api/v1/event/stop", json = stop_data, cookies = Login.cookies )
    json_data = json.loads(resp.text)
    print(json_data)

    print("The Response of stop is" )
    print(resp)
    return

Login()

for i in range(10):
    APIStartEventCall()
    time.sleep(30)
    APIStopEventCall()
    time.sleep(60)


print("I'm at the end of your script ")
