from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import mysql.connector
import requests
import json
from http.client import HTTPSConnection
from requests.auth import HTTPBasicAuth
import threading
import datetime


global driver
driver = webdriver.Chrome()
driver.get("https://dev.gabriel.network/emergency")


def Login():

    TypeEmail = driver.find_element_by_name("email").send_keys('security@customer1.com')
    TypePassword = driver.find_element_by_name('password').send_keys('gabriel')
    Submit = driver.find_element_by_css_selector("button").click() #submit
    Hold4sec = time.sleep(1)
    TypeEmail
    TypePassword
    Submit
    Hold4sec
    return

def StartEmergenctInJFMD():

    PlusIcon = driver.find_element_by_xpath('//*[@id="root"]/div/span/div/div[2]/ul/div/li[1]').click() # plus icon
    print("I clicked on plus Icon")
    ClickOnLockDown = driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/div/div/div[2]/button[1]").click() #lockdown
    print("I clicked on lockdown")
    ClickOnArrow = driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/div/div/div[2]/div[1]/div/span[2]").click() #Arrow
    print("I clicked on arrow")
    TypeJFMD = driver.find_element_by_xpath('//*[@id="react-select-2--value"]/div[2]/input').send_keys('jfmd' + "\n")#jfmd
    print("I typed JFMD")
    time.sleep(10)

    ClickOnStart = driver.find_element_by_class_name("start-event-button").click() #START
    print("I clicked on start JFMD")

    PlusIcon
    print("line 41")
    ClickOnLockDown
    print("line 43")
    ClickOnArrow
    print("line 45")
    TypeJFMD
    print("line 47")
    ClickOnStart
    print("line 49")

    return


def CloseTwoEvents():
    time.sleep(20)
    driver.find_element_by_class_name('emergency-type-dropdown').click()
    time.sleep(10)
    print("line 57")
    driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/nav/div/ul[3]/li/ul/li[3]/a/div').click()#end energency
    time.sleep(5)
    print("line 61")
    driver.find_element_by_xpath('//*[@id="root"]/div/span/div/div[2]/ul/div/li[1]/a').click()#belIcon
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="root"]/div/span/div[1]/div/div/div[1]').click() #JCC
    time.sleep(10)
    driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/nav/div/ul[3]').click()
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/nav/div/ul[3]/li/ul/li[3]').click()#end energency
    time.sleep(5)

    return

def MainFunction():

    Login()
    StartEmergenctInJFMD()
    CloseTwoEvents()

    t=threading.Timer(5.0, MainFunction)
    t.start()

    return

MainFunction()
