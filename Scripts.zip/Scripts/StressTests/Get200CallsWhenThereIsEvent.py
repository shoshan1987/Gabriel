from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import mysql.connector
import requests
import json
from http.client import HTTPSConnection
from requests.auth import HTTPBasicAuth
import threading
import datetime


global driver
driver = webdriver.Chrome()
driver.get("https://dev.gabriel.network/emergency")


def Login():

    TypeEmail = driver.find_element_by_name("email").send_keys('security@customer1.com')
    TypePassword = driver.find_element_by_name('password').send_keys('gabriel')
    Submit = driver.find_element_by_css_selector("button").click() #submit
    Hold4sec = time.sleep(1)
    TypeEmail
    TypePassword
    Submit
    Hold4sec
    return

def CheckingIfThereIsEventOrNot():
    mydb = mysql.connector.connect(
    host="104.196.181.106",
    user="root",
    passwd="Gabriel@2018",
    database="gabriel"
    )
    mycursor = mydb.cursor()
    mycursor.execute("select status from PrxEvent where propertyId = 1 order by eventId desc limit 1;")
    EventId = mycursor.fetchall()

    status = " ".join(str(EventId))
    print("The status is" + status)
    CheckingIfThereIsEventOrNot.status = status
    return

def StartEmergenctInJFMD():

    PlusIcon = driver.find_element_by_xpath('//*[@id="root"]/div/span/div/div[2]/ul/div/li[1]').click() # plus icon
    ClickOnLockDown = driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/div/div/div[2]/button[1]").click() #lockdown
    ClickOnArrow = driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/div/div/div[2]/div[1]/div/span[2]").click() #Arrow
    TypeJFMD = driver.find_element_by_xpath('//*[@id="react-select-2--value"]/div[2]/input').send_keys('jfmd' + "\n")#jfmd
    ClickOnStart = driver.find_element_by_xpath("/html/body/div[2]/div/div[2]/div/div/div[2]/div[3]").click() #START

    PlusIcon
    ClickOnLockDown
    ClickOnArrow
    TypeJFMD
    ClickOnStart

    return


def TakeEventIdFromMySqlAndConvertItToStr():
    mydb = mysql.connector.connect(
    host="104.196.181.106",
    user="root",
    passwd="Gabriel@2018",
    database="gabriel"
    )

    mycursor = mydb.cursor()
    mycursor.execute("select eventId from PrxEvent where propertyId = 1 order by eventId desc limit 1;")
    EventId = mycursor.fetchall()

    string = " ".join(str(EventId))
    print(string)
    TakeEventIdFromMySqlAndConvertItToStr.string = string
    return

def CloseTwoEvents():
    driver.find_element_by_class_name('emergency-type-dropdown').click()
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/nav/div/ul[3]/li/ul/li[3]/a/div').click()#end energency
    time.sleep(4)
    driver.find_element_by_xpath('//*[@id="root"]/div/span/div/div[2]/ul/div/li[1]/a').click()#belIcon
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="root"]/div/span/div[1]/div/div/div[1]').click() #JCC
    time.sleep(10)
    driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/nav/div/ul[3]').click()
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/nav/div/ul[3]/li/ul/li[3]').click()#end energency
    time.sleep(5)

    return

def Get200CallsWhenThereIsEvent():

    login_data =  {"email":"security@customer1.com", "password": "gabriel"}
    s= requests.Session()
    r = s.post('https://dev.gabriel.network/api/v1/login', json=login_data )

    json_data_post = json.loads(r.text)
    cookies = r.cookies
    print(json_data_post["json"]["user"]["email"])
    MakeCallOfEventState(cookies)

    return

def MakeCallOfEventState(cookies):

    EventNumberString = TakeEventIdFromMySqlAndConvertItToStr.string
    EventNumberStringList = list(EventNumberString)
    EventId = EventNumberStringList[4] + EventNumberStringList[6] + EventNumberStringList[8] + EventNumberStringList[10]


    resp = requests.get("https://dev.gabriel.network/api/v1/event/" + EventId + "/state", cookies=cookies)
    json_data = json.loads(resp.text)

    print("The Response is" )
    print(resp)
    t=threading.Timer(5.0, MakeCallOfEventState, [cookies])
    t.start()

    return

def repeat_fun(times):
    for i in range(0,times):
        Get200CallsWhenThereIsEvent()

    return

def MainFunction():
    Login()
    CheckingIfThereIsEventOrNot()
    if CheckingIfThereIsEventOrNot.status == "[ ( 1 , ) ]" :
       StartEmergenctInJFMD()
    else:
       CloseTwoEvents()
       StartEmergenctInJFMD()
    TakeEventIdFromMySqlAndConvertItToStr()

    times = input("How many times do you want to run the script in a loop?: ")
    repeat_fun(times)

MainFunction()
