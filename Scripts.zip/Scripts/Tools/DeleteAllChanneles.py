import requests
import json
from requests.auth import HTTPBasicAuth


def GetAllChannelsAndDeleteThem (SID):
    Deleting (SID)
    if SID == 'IS395e13edc6eb4fb5942fb3ac5f4ad8d0':
        print ("You deleted all dev channels. Good Job!")
    elif (SID == ' ISa493915aaf124692890251983ffd69ba'):
        print ("You deleted all localhost channels. Good Job!")
    elif  (SID == 'ISa493915aaf124692890251983ffd69ba'):
        print ("You deleted all prod channels. Good Job!")

    return

def GetAllUsersAndDeleteThem (SID):
    DeletingUsers (SID)
    if SID == 'IS395e13edc6eb4fb5942fb3ac5f4ad8d0':
        print ("You deleted all dev users. Good Job!")
    elif (SID == 'ISa493915aaf124692890251983ffd69ba'):
        print ("You deleted all localhost users. Good Job!")
    elif  (SID == 'ISa493915aaf124692890251983ffd69ba'):
        print ("You deleted all prod users. Good Job!")
    return

def l():
    inp = str(raw_input("What do you want to earse. Choose c for channels,  u for users, or b for both: "))
    SID = 'IS2be0fc01c67e44cd9b2423987cac1b81'
    if (inp == 'c'):
        print('c')
        GetAllChannelsAndDeleteThem (SID)
    elif (inp == 'u'):
        print('u')
        GetAllUsersAndDeleteThem (SID)
    elif (inp == 'b'):
        print('b')
        GetAllChannelsAndDeleteThem (SID)
        GetAllUsersAndDeleteThem (SID)

def d():
    inp = str(raw_input("What do you want to earse. Choose c for channels,  u for users, or b for both: "))
    SID = 'IS395e13edc6eb4fb5942fb3ac5f4ad8d0'
    if (inp == 'c'):
        print('c')
        GetAllChannelsAndDeleteThem (SID)
    elif (inp == 'u'):
        print('u')
        GetAllUsersAndDeleteThem (SID)
    elif (inp == 'b'):
        print('b')
        GetAllChannelsAndDeleteThem (SID)
        GetAllUsersAndDeleteThem (SID)

def p():
    SID = 'ISa493915aaf124692890251983ffd69ba'
    input_pass = str(raw_input("Please enter password:  "))
    if (input_pass == 'gabriel18'):
        inp = str(raw_input("What do you want to earse. Choose c for channels,  u for users, or b for both: "))

        if (inp == 'c'):
            print('c')
            GetAllChannelsAndDeleteThem (SID)
        elif (inp == 'u'):
            print('u')
            GetAllUsersAndDeleteThem (SID)
        elif (inp == 'b'):
            print('b')
            GetAllChannelsAndDeleteThem (SID)
            GetAllUsersAndDeleteThem (SID)
    else:
        print("Wrong password")
        return

def Deleting (SID):

    username = 'AC19bfd16640a918a6904b183fb0d29c9a'
    password = '5bf266235afa9ed03338cf9f11b37064'

    resp = requests.get('https://chat.twilio.com/v2/Services/' + SID + '/Channels', auth=HTTPBasicAuth(username, password))
    json_data = json.loads(resp.text)

    if len(json_data["channels"]) == 0:
        return

    for item in json_data["channels"]:
        resp_b = requests.delete("https://chat.twilio.com/v2/Services/" + SID + "/Channels/"+ item["sid"] , auth=HTTPBasicAuth(username, password))
        print(item["sid"])
        print(resp_b)

    Deleting(SID)
    return


def DeletingUsers (SID):

    username = 'AC19bfd16640a918a6904b183fb0d29c9a'
    password = '5bf266235afa9ed03338cf9f11b37064'

    resp = requests.get('https://chat.twilio.com/v2/Services/' + SID + '/Users', auth=HTTPBasicAuth(username, password))
    json_data = json.loads(resp.text)

    if len(json_data["users"]) == 0:
        return

    for item in json_data["users"]:
        resp_b = requests.delete("https://chat.twilio.com/v2/Services/" + SID + "/Users/"+ item["sid"] , auth=HTTPBasicAuth(username, password))
        print (resp_b)

    DeletingUsers(SID)
    return

####################
# ---main program---
####################

inp = str(raw_input("Which database do you want to erase from it?   \n" + "d - Dev \nl - Loccalhost \np - Production\n"))

if (inp == 'd'):
    print(inp)
    d()
elif (inp == 'l'):
    l()
elif (inp == 'p'):
    p()
